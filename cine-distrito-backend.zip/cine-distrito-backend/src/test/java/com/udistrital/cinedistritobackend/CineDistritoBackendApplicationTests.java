package com.udistrital.cinedistritobackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CineDistritoBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
